// app.js
import { serve } from '@hono/node-server';
import { Hono } from 'hono';
import { getOlabibaResponse } from './olaba.js';
// Ubah nama import agar lebih jelas bahwa ini adalah Class
import DeepSeekClient from './deepsek.js'; 

const port = Number(process.env.PORT || process.env.SERVER_PORT || 4000);
const app = new Hono();

// Daftar API Key yang kamu miliki
const API_KEYS = [
    'BWV+YqYDvck47J9SvQFWiO5e2dt0feI7EraaoV2J5WQztMVw4xW64vw4hBKz6sqh',
    'fR3AbopXwzh9y9behMnDFGnTMf3p+NnKwhKh92h/gTOZKwXZED8yRx3WkdVJHaau',
    'bmjFh7xA6zTBsbAbZyk4EWDXnIZqSpl2ycr1IBj3v6+gxHVGATzX/vBdn4EADDCr',
    'Ewh9vG3agJMS/IH6Da/5juXAmQbf4PHGoa546N1m9OjVWR/tVHI+yQfjZBTr8EIw'
];

// Map sekarang akan menyimpan objek: { apiKey: string, count: number }
const sessionKeys = new Map();
const MAX_SESSIONS = 10; // Maksimal 10 chat id berbeda di memori

app.get('/', (c) => {
  return c.json({
    status: true,
    message: 'Api aktif'
  });
});

app.get('/chat/deepseek', async (c) => {
  const query = c.req.query('q');
  const idchat = c.req.query('id');

  if (!query) {
    return c.json({ 
      status: 'error', 
      message: 'Parameter "q" (pertanyaan) wajib disertakan' 
    }, 400);
  }

  try {
    console.log(`Memproses pertanyaan: "${query}"...`);
    
    let selectedApiKey;
    let chatCount = 0; // Default untuk request pertama

    // Logika pemilihan API Key & penghitungan count
    if (idchat && sessionKeys.has(idchat)) {
      const sessionData = sessionKeys.get(idchat);
      selectedApiKey = sessionData.apiKey;
      
      // Karena idchat sudah ada, kita tambah count pemakaiannya
      chatCount = sessionData.count + 1; 
      console.log(`Menggunakan API Key yang sudah ada untuk sesi: ${idchat}`);
    } else {
      // Jika request baru atau idchat tidak dikenali
      const randomIndex = Math.floor(Math.random() * API_KEYS.length);
      selectedApiKey = API_KEYS[randomIndex];
      chatCount = 0; 
      console.log(`Menggunakan API Key acak untuk request baru.`);
    }

    // --- BAGIAN YANG DIUBAH ---
    // chatnum adalah kelipatan 2 dari berapa kali request dilakukan.
    // Jika chatCount = 0, jadikan null. Jika tidak, kalikan 2.
    const chatnum = chatCount === 0 ? null : chatCount * 2;

    // INSTANSIASI BARU UNTUK SETIAP REQUEST
    const deepseek = new DeepSeekClient();

    // Bind API Key ke instance yang baru dibuat
    await deepseek.bind(selectedApiKey);

    // Panggil fungsi chat (sekarang chatnum akan berisi null di request pertama)
    const aiResponse = await deepseek.chat(query, idchat, chatnum);
    
    // AMBIL ID DARI RESPONSE AI
    const responseChatId = aiResponse?.data?.id;

    // Simpan API Key dan Count ke dalam session map menggunakan ID dari AI
    if (responseChatId) {
      
      // CEK BATAS MAKSIMAL MEMORI (10 SESI)
      if (!sessionKeys.has(responseChatId) && sessionKeys.size >= MAX_SESSIONS) {
        const oldestKey = sessionKeys.keys().next().value;
        sessionKeys.delete(oldestKey);
        console.log(`Memori penuh! Menghapus sesi terlama: ${oldestKey}`);
      }

      // Simpan atau update data sesi terbaru
      sessionKeys.set(responseChatId, {
        apiKey: selectedApiKey,
        count: chatCount
      });
      
      console.log(`Update sesi ID: ${responseChatId} | Dikirim dengan chatnum: ${chatnum}`);
    }
  
    return c.json({
      status: 'success',
      user_query: query,
      ai_response: aiResponse,
      chat_id: responseChatId
    });
  } catch (error) {
    console.error('Error:', error.message);
    return c.json({ 
      status: 'error', 
      message: 'Terjadi kesalahan pada server AI' 
    }, 500);
  }
});


// Endpoint utama olabiba tetap sama...
app.get('/chat/olabiba', async (c) => {
  const query = c.req.query('q');

  if (!query) {
    return c.json({ 
      status: 'error', 
      message: 'Parameter "q" (pertanyaan) wajib disertakan' 
    }, 400);
  }

  try {
    const aiResponse = await getOlabibaResponse(query);
    return c.json({
      status: 'success',
      user_query: query,
      ai_response: aiResponse
    });
  } catch (error) {
    console.error('Error:', error.message);
    return c.json({ 
      status: 'error', 
      message: 'Terjadi kesalahan pada server AI' 
    }, 500);
  }
});

console.log(`🚀 Server berjalan di http://localhost:${port}`);

serve({
  fetch: app.fetch,
  port
});
