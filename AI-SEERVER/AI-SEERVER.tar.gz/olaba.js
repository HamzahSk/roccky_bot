// scraper.js
import crypto from 'node:crypto';

export async function getOlabibaResponse(pertanyaan) {
  const PHPSESSID = crypto.randomBytes(13).toString('hex');
  const HEADERS = {
    'referer': 'https://www.olabiba.com/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36',
    'cookie': `PHPSESSID=${PHPSESSID};`
  };

  // 1. Kirim Pesan (Inisiasi)
  const formData = new FormData();
  formData.append('text', pertanyaan);
  formData.append('mood', 'funny');
  formData.append('lang', 'id');
  formData.append('adblock', 'No');
  formData.append('theme', 'light');

  const res = await fetch('https://www.olabiba.com/php/message.php', {
    method: 'POST',
    headers: HEADERS,
    body: formData
  });

  if (!res.ok) throw new Error(`Gagal inisiasi: HTTP ${res.status}`);

  // 2. Jalankan Stream dan kumpulkan teksnya
  const streamRes = await fetch('https://www.olabiba.com/php/stream.php', {
    method: 'GET',
    headers: { ...HEADERS, 'accept': 'text/event-stream' }
  });

  if (!streamRes.ok) throw new Error(`Gagal stream: HTTP ${streamRes.status}`);

  const decoder = new TextDecoder();
  let fullResponse = '';

  for await (const chunk of streamRes.body) {
    const text = decoder.decode(chunk, { stream: true });
    const lines = text.split('\n');

    for (const line of lines) {
      if (line.startsWith('data:')) {
        const data = line.replace('data:', '').trim();
        if (data === '[DONE]') {
          // Bersihkan teks akhir sebelum di-return ke server
          return fullResponse
            .replaceAll('&nbsp;', ' ')
            .replace(
  /\[ELABORATE\]|\[FOLLOWUP\].*|<!--QUERY:[\s\S]*?-->/g,
  ''
)
            .trim();
        }
        fullResponse += data;
      }
    }
  }
  
  return fullResponse;
}
